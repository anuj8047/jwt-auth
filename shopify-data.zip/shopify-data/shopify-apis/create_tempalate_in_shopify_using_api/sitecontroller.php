<?php

namespace frontend\controllers; 

use frontend\models\ResendVerificationEmailForm;

use frontend\models\VerifyEmailForm;

use Yii;

use yii\base\InvalidArgumentException;

use yii\web\BadRequestHttpException;

use yii\web\Controller;

use yii\filters\VerbFilter;

use yii\filters\AccessControl;

use common\models\LoginForm;

use frontend\models\Shops;

use frontend\models\ShopifyClient;

use frontend\models\Truequiz;

use frontend\models\Setting;

use frontend\models\Nftids;   

use frontend\models\Cart;

use frontend\models\Api;

use frontend\models\Orders;

use frontend\models\Orderitem;

use yii\web\UploadedFile; 

header("Access-Control-Allow-Origin: *");

header("Access-Control-Allow-Credentials: true ");


class SiteController extends Controller{



    /**



     * {@inheritdoc}



     */

    public $enableCsrfValidation = false;

    public function behaviors(){

        return [

            'access' => [

                'class' => AccessControl::className(),

                'only' => ['logout', 'signup'],

                'rules' => [

                    [

                        'actions' => ['signup'],

                        'allow' => true,

                        'roles' => ['?'],

                    ],

                    [ 

                        'actions' => ['logout'],

                        'allow' => true,

                        'roles' => ['@'],

                    ],

                ],

            ],

            'verbs' => [

                'class' => VerbFilter::className(),

                'actions' => [

                    'logout' => ['post']

                ],

            ],

        ];

    }



    /**

     * {@inheritdoc}

     */

    public function actions(){

        return [

            'error' => [

                'class' => 'yii\web\ErrorAction', 

            ],

            'captcha' => [

                'class' => 'yii\captcha\CaptchaAction',

                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,

            ],

        ];

    } 





    /** 

     * Displays homepage.

     *

     * @return mixed  */

   

    public function getShopifyProducts()
    {
        
            $shop = $_GET['shop'];

			$getToken = Truequiz::find()->where(['store_shop' => $shop])->one();

			$store_id = $getToken['store_id'];

			$shopify_token = $getToken['store_token'];

	        $url = "https://".$shop."/admin/api/2021-07/products.json";
	        $curl = curl_init($url);
	        curl_setopt($curl, CURLOPT_URL, $url);
	        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	        $headers = array(
	            "Accept: application/json",
	            "X-Shopify-Access-Token: " . $shopify_token,
	        );
	        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	        $products = curl_exec($curl);
	        curl_close($curl);

	        $products = json_decode($products,true);
	        
	        return $products;
    }


	public function actionIndex(){
		
				if(isset($_POST['submit_add'])) {
					$shop = $_GET['shop'];
			if(isset($_COOKIE["art_cid"])) {
					$c_customer_id=$_COOKIE["art_cid"];
					$this->actionCheckProduct($_POST['height'], $_POST['width'], $_POST['final_image'], $c_customer_id,$shop, $_POST['thumb_img']);
			}else{
								$this->actionProductAdd($_POST['height'], $_POST['width'], $_POST['final_image'],$shop, $_POST['thumb_img']);
					}
				}
				
				
				 
				
		if(isset($_GET['pro'])) {  
			 $id=$_GET['pro'];
				 
			 $sql = "SELECT image,height,width from customer_product where variant_id='$id'";
			 $commands = Yii::$app->db->createCommand($sql);
			 $qwer= $commands->queryAll();
				if(!empty($qwer)){
						 print_r(json_encode($qwer[0]));
				}
				
				  return false;
		}
		
	/* CHECK PRODUCT TAGS */
	
		if(isset($_POST['check_product'])) {  	
		$shop = $_POST['shop'];
		$getToken = Truequiz::find()->where(['store_shop' => $shop])->one();
		$store_id = $getToken['store_id'];
	    $shopify_token = $getToken['store_token'];
		$shopifyClient = new ShopifyClient($shop,$shopify_token,Yii::$app->params["APP_KEY"],Yii::$app->params["SECRET_KEY"]);
		//$all_data = $shopifyClient->call("GET", "/admin" . Yii::$app->params["API_DATE"] . "products.json?fields=id,tags,title");	
		return 'check_product';
		}
		
	 /* END CHECK PRODUCT TAGS */		
	 
if(isset($_POST['check_productt'])) {  	
	$shop = $_POST['shop'];
	$customer_idd = $_POST['customer_idd'];
		  $sql = "SELECT product_id,url from prdct_data	 where customer_id='$customer_idd'";
			 $commands = Yii::$app->db->createCommand($sql);
			 $qwer= $commands->queryAll();
			 if(!empty($qwer)){
						 print_r(json_encode($qwer));
				}
				
				  return false;
		}
	 
	 if(isset($_POST['shopp'])) {
		$shopp=$_POST['shopp'];
			$this->actionGetbox($shopp);
	}
		if(isset($_GET['shop']) && $_GET['shop'] != ''){

			$shop = $_GET['shop'];

			$session = Yii::$app->session;		 

			$session->open(); 

			$session->set('shop', $shop); 

			$products = $this->getShopifyProducts();

            
            $msg = '';

			 if(isset($_POST['submit']))
		     {

		     	 $data = $_POST;

		         unset($data['submit']);

                 if(isset($_POST['file_type'])) {
                   $data['file_type'] = serialize($data['file_type']);
				 }
                 
                 $product_id = $data['product_id'];

                 $sql = "SELECT * from products where product_id= '$product_id' limit 1";

                 $commands = Yii::$app->db->createCommand($sql);
                  $qwer= $commands->queryOne();
				  Yii::$app->db->createCommand()->truncateTable('admin_product')->execute();
                  if(empty($qwer)){
                    Yii::$app->db->createCommand()->insert('products',$data)->execute();
                    Yii::$app->db->createCommand()->insert('admin_product',$data)->execute();
						
                     $msg = 'A product successfully added.';


                  }else{
          
			         Yii::$app->db->createCommand()->update('products',$data,['product_id' => $product_id])->execute();
					 Yii::$app->db->createCommand()->insert('admin_product',$data)->execute();
		             $msg = 'A product successfully updated.';
                  } 

		      }
			   return $this->render('index', ['shop' => $shop,'products'=>$products,"msg"=>$msg]);

		
			}else{

			   return $this->render('error');

			}

    } 

 /**
	*@param $h Height
	*@param $w Widht
	*@param $img Product Image
	**/
    function actionCheckProduct($h, $w, $img, $c_customer_id,$shop,$thumb) {
		$getToken = Truequiz::find()->where(['store_shop' => $shop])->one();
		$store_id = $getToken['store_id'];
		    $sql = "SELECT product_id,variant_id,image from customer_product where height= '$h' and width ='$w' and customer_id='$c_customer_id'";
                 $commands = Yii::$app->db->createCommand($sql);
				 $qwer= $commands->queryAll();
				    $shopify_token = $getToken['store_token'];
if(!empty($qwer)){		
	
	foreach( $qwer as $qwe ){
			 $rst= $qwe['variant_id'];
			 $product_id= $qwe['product_id'];
	    }
		$sql1 = "SELECT url from prdct_data where height= '$h' and width ='$w' and product_id='$product_id'";
                 $command1s = Yii::$app->db->createCommand($sql1);
				 $qwer1= $command1s->queryAll();
	foreach( $qwer1 as $qwe1 ){} 
	$rsftv= $qwe1['url']; 
		sleep(4);
		header("Location: $rsftv");
	}else{
		$this->actionProductAdd($h, $w, $img,$shop,$thumb);
	
		 }
  }

    /**
	*@param $h Height
	*@param $w Widht
	*@param $img Product Image
	**/

    function actionProductAdd($h, $w, $img, $shop ,$thumb)
    {
       
        /* Get product in seetings */
        $sql1 = "SELECT product_id ,sku_prefix from admin_product";
        $command1s = Yii::$app->db->createCommand($sql1);
        $qwer1 = $command1s->queryAll();
        foreach ($qwer1 as $qwe1) {}
		if(!empty($qwe1)){
        $product_id = $qwe1["product_id"];
        $sku_prefix = $qwe1["sku_prefix"];
		$getToken = Truequiz::find()->where(["store_shop" => $shop])->one();
        $store_id = $getToken["store_id"];
        $shopify_token = $getToken["store_token"];
		$shopifyClient = new ShopifyClient($shop,$shopify_token,Yii::$app->params["APP_KEY"],Yii::$app->params["SECRET_KEY"]);
        $all_data = $shopifyClient->call("GET","/admin" .Yii::$app->params["API_DATE"] ."products/" .$product_id .".json");
		if(isset($all_data['errors'])){
				$go="https://".$shop."/pages/customer-look-up?product-added=error";
					   header("Location: $go");
			exit();			
		}
        $des_ct = $all_data["body_html"];
        $imgg = $all_data["image"]["src"];
        $title = $all_data["title"];
		$hei=str_replace(".","",$h);
		$wid=str_replace(".","",$w);
		$skuu=$sku_prefix.'-'.$hei.$wid;
        /** End get dynamic product name  **/
        $json_arr = [
            "product" => [
                "title" => $title . " " . $h . "X" . $w . "",
                "body_html" => $des_ct,
                "vendor" => "",
                "tags" => "user_product",
                "product_type" => $title,
                "variants" => [
                    [
                        "option1" => $h.'/'.$w,
                        "price" => $h * $w,
                        "sku" => $skuu,
                        "values" => [$h.'/'.$w],
                    ],
                ],
            ],
        ];
		 $shopify_token = $getToken["store_token"];

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL =>
                "https://" . $shop . "/admin/api/2022-10/products.json",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($json_arr),
            CURLOPT_HTTPHEADER => [
                "Accept: application/json",
                "Content-Type: application/json",
                "X-Shopify-Access-Token: " . $shopify_token,
            ],
        ]);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            echo json_encode([
                "message" => "Product not added",
                "type" => "error",
            ]);
            header(
                "Location: https://".$shop."/pages/customer-look-up?product-added=error"
            );
        } else {
            $product = json_decode($response, true);
				if(isset($product['errors'])){
					$go="https://".$shop."/pages/customer-look-up?product-added=error";
					   header("Location: $go");
				exit();
				}
            $product_id = $product["product"]["id"];
            $variants = $product["product"]["variants"];
            $variant_ids = array_column($variants, "id");
            $this->insertProductImages($product_id,$variant_ids,$imgg,$shop,$shopify_token,$h,$w,$thumb);
            $url ="https://".$shop."/products/" .$product["product"]["handle"];
            $this->InsertDatabase($product_id,$variant_ids,$imgg,$h,$w,$url,$img,$thumb);
            header("Location: $url");
        }

        exit();
		}else{
			  $json_arr = [
            "product" => [
                "title" => "Custom Art " . " " . $h . "X" . $w . "",
                "body_html" => "This is description",
                "vendor" => "",
                "tags" => "user_product",
                "variants" => [
                    [
                        "option1" => $h.'/'.$w,
                        "price" => $h * $w,
                        "values" => [$h.'/'.$w],
                    ],
                ],
            ],
        ];
		 $shopify_token = $getToken["store_token"];

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL =>
                "https://" . $shop . "/admin/api/2022-10/products.json",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($json_arr),
            CURLOPT_HTTPHEADER => [
                "Accept: application/json",
                "Content-Type: application/json",
                "X-Shopify-Access-Token: " . $shopify_token,
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            echo json_encode([
                "message" => "Product not added",
                "type" => "error",
            ]);
            header(
                "Location: https://".$shop."/pages/customer-look-up?product-added=error"
            );
        } else {
			$imgg='https://cdn.shopify.com/s/files/1/0684/6663/9158/products/coffeeco.png?v=1671566467';
			$img='https://cdn.shopify.com/s/files/1/0684/6663/9158/products/coffeeco.png?v=1671566467';
			$thumb='https://cdn.shopify.com/s/files/1/0684/6663/9158/products/coffeeco.png?v=1671566467';
            $product = json_decode($response, true);
            $product_id = $product["product"]["id"];
            $variants = $product["product"]["variants"];
            $variant_ids = array_column($variants, "id");
            $url ="https://".$shop."/products/" .$product["product"]["handle"];
            $this->InsertDatabase($product_id,$variant_ids,$imgg,$h,$w,$url,$img,$thumb);
            header("Location: $url");
        }

        exit();
		}
       
    }
    
	
	/**
	*@param $id Product Id
	*@param $variants Product variants array
	*@param $Image Poster Image
	*@param $token Shopify Token
	**/
    function insertProductImages($id, $variants, $image, $shop, $token, $h, $w,$thumb) { 
		$data =[
			   "image" => [
					 "src" => $image
					// "src" => 'https://test-api-ubzqe5vs2q-uc.a.run.app/api/v1/asset/id/eyJrIjoiMSJ9.KECAH45bMy7G8FXUo5TMVu7aRvYSoyXy13IX7vheJnA.JrSj3dR0WwkOMyOq4D5XeO3PeraqmFWDDNBoFuVarh4'					 
				  ] 
			]; 
 
            $curl = curl_init();
			curl_setopt_array($curl, [
			  CURLOPT_URL => "https://".$shop."/admin/api/2022-10/products/".$id."/images.json",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "POST",
			  CURLOPT_POSTFIELDS => json_encode($data),
			  CURLOPT_HTTPHEADER => [
				"Accept: application/json",
				"Content-Type: application/json",
				"X-Shopify-Access-Token: ".$token
			  ],
			]);

			$response = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			if ($err) {
				echo json_encode(array('message' => 'Images not added', 'type' => 'error'));
			} else {
				//echo $response;
				$image = json_decode($response, true);
				
			}
			 foreach( $image as $imgg ){}
			$img_id=$imgg['id'];
				  foreach( $variants as $var ){
			$dataa =[
			   "variant" => [
					 "image_id" => $img_id,			 
				  ] 
			]; 
				  $curl = curl_init();
			curl_setopt_array($curl, [
			  CURLOPT_URL => "https://".$shop."/admin/api/2022-10/variants/$var.json",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "PUT",
			  CURLOPT_POSTFIELDS => json_encode($dataa),
			  CURLOPT_HTTPHEADER => [
				"Accept: application/json",
				"Content-Type: application/json",
				"X-Shopify-Access-Token: ".$token
			  ],
			]);

			$responsee = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);
			
				  }
       $this->variantTitle($id, $variants, $shop, $token,$thumb);

	}
	
	/* variants price */
	function variantTitle($id, $variants, $shop, $token,$thumb){
		$optionsArray[] = array( "name" => "Height/Width");
		$data = array(
    'product' => array(
        'options' => $optionsArray,
    ));
					  $curl = curl_init();
			curl_setopt_array($curl, [
			  CURLOPT_URL => "https://".$shop."/admin/api/2022-10/products/".$id.".json",
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => "",
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 30,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => "PUT",
			  CURLOPT_POSTFIELDS => json_encode($data),
			  CURLOPT_HTTPHEADER => [
				"Accept: application/json",
				"Content-Type: application/json",
				"X-Shopify-Access-Token: ".$token
			  ],
			]);

			$responsees = curl_exec($curl);
			$err = curl_error($curl);
			curl_close($curl);	
			
			
	// METAFIELD auto genaraeted 
 $arg = [
		"metafield" => [
			"name" => 'Tool Option',
			"namespace" => "product",
			"key" => "tool_option",
			"value" => true,
			"type" => "boolean",
		   
		],
	];
	$getToken = Truequiz::find()->where(['store_shop' => $shop])->one();
		$store_id = $getToken['store_id'];
	    $shopify_token = $getToken['store_token'];
		        $shopifyClient = new ShopifyClient($shop,$shopify_token,Yii::$app->params["APP_KEY"],Yii::$app->params["SECRET_KEY"]);

	$meta_field = $shopifyClient->call("POST", "/admin" . Yii::$app->params["API_DATE"] . "products/".$id."/metafields.json", $arg);
			
	}
	/* End variants price */
	
	/* ********INSERT DATA IN DATABASE ****** */
	function InsertDatabase($product_id, $variant_ids, $imgg, $h, $w, $url,$img,$thumb){
			if(!isset($_COOKIE["art_cid"])){
			$queryy="INSERT INTO `customer`(`value`) VALUES ('1')";
							Yii::$app->db->createCommand($queryy)->execute();
							 $sql = "SELECT customer_id from customer ORDER BY customer_id desc limit 1";
						 $commands = Yii::$app->db->createCommand($sql);
						 $qwer= $commands->queryAll();
						$id=$qwer[0]["customer_id"]; 
				setcookie("art_cid",$id, time() + 31556926, "/");
			}
			foreach($variant_ids as $iid){
					if(isset($_POST["customer_id"])){
						$c__id=$_POST["customer_id"];
					$query="INSERT INTO `prdct_data`(`product_id`, `variant_id`, `height` ,`width`,`img`,`url`,`customer_id`) VALUES ('$product_id','$iid','$h','$w','$img','$url','$c__id')";
						}else{
						$query="INSERT INTO `prdct_data`(`product_id`, `variant_id`, `height` ,`width`,`img`,`url`) VALUES ('$product_id','$iid','$h','$w','$img','$url')";
						}
					Yii::$app->db->createCommand($query)->execute();
				if(isset($_COOKIE["art_cid"])){
					$vb=$_COOKIE["art_cid"];
					$insert="INSERT INTO `customer_product`(`customer_id`, `product_id`, `variant_id` ,`image`, `height` ,`width`) VALUES ('$vb','$product_id','$iid','$thumb','$h','$w')";
						Yii::$app->db->createCommand($insert)->execute();
				}else{
					$insert="INSERT INTO `customer_product`(`customer_id`, `product_id`, `variant_id` ,`image`, `height` ,`width`) VALUES ('$id','$product_id','$iid','$thumb','$h','$w')";
					Yii::$app->db->createCommand($insert)->execute();
				}
					
			}

	}
	/* ********INSERT DATA IN DATABASE *******/
    public function actionInstall(){ 
        $shop = Yii::$app->getRequest()->getQueryParam('shop');

        $code = Yii::$app->getRequest()->getQueryParam('code');



        $shopify_token = '';

        $Truequiz = Truequiz::find()->where(['store_shop' => $shop])->one();

        

        if (empty($Truequiz->store_token)){

            

            $shopifyClient = new ShopifyClient($shop, "", Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);

            $shopify_token = $shopifyClient->getAccessToken($code);

            $shopify_shop = $shop;

            $shopify_code = $code;

            if (empty($shopify_token)){

                header("Location: " . $shopifyClient->getAuthorizeUrl(Yii::$app->params['SHOPIFY_SCOPE'], Yii::$app->params['REDIRECT_URI']));

                exit;

            }else{

                $TruequizInsert = new Truequiz();

                $TruequizInsert->store_token = $shopify_token;

                $TruequizInsert->store_shop = $shopify_shop;

                $TruequizInsert->store_code = $shopify_code;

                $shopifyClint = new ShopifyClient($shopify_shop, $shopify_token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);

                $myhooks = array();



                $checkhooks = $shopifyClint->call('GET', '/admin'.Yii::$app->params['API_DATE'].'webhooks.json');

				

				

                if (!empty($checkhooks)){

                    foreach($checkhooks as $exist_hooks){

						if(!empty($exist_hooks)){

							$myhooks[] = $exist_hooks['topic'];

						}

                    }

                }

                if (!in_array("app/uninstalled", $myhooks)){

                     $uninstallhook = array(

                        "webhook" => array(

                            "topic" => "app/uninstalled",

                            "address" => Yii::$app->params['BASE_URL'] . "appuninstall?shop=" . $shop,

                            "format" => "json"

                        )

                    );

                    $hook1 = $shopifyClint->call('POST', '/admin'.Yii::$app->params['API_DATE'].'webhooks.json', $uninstallhook);

                }





                if ($TruequizInsert->save(false)){

					$web_url = Yii::$app->params['WEB_URL'];	

                    // Inject script

                    $arg = array(

                        "script_tag" => array(

                            "event" => "onload",

                            "src" => $web_url."/js/flashypawz.js",

                        )

                    );



                    $inject_js = $shopifyClint->call('POST', '/admin'.Yii::$app->params['API_DATE'].'/script_tags.json', $arg);

                    $session = Yii::$app->session;

                    $session->open();

                    $session->set('shop', $shop);

                    header('Location:' . 'https://' . $shop . '/admin/apps/'.Yii::$app->params['APP_SLUG']);

                    exit;

                }else{

                    Yii::$app->session->setFlash('error', json_encode($Truequiz->getErrors()));

                    $session = Yii::$app->session;

                    $session->open();

                    $session->set('shop', $shop);

                    header('Location:' . 'https://' . $shop . '/admin/apps/'.Yii::$app->params['APP_SLUG']);

                    exit;

                }

            }

        }else{

            $session = Yii::$app->session;

            $session->open();

            $session->set('shop', $shop);

            $this->redirect('index/?shop=' . $shop); 

        }

    }


function actionGetgraphql(){

          $shop = $_GET['shop'];

            $getToken = Truequiz::find()->where(['store_shop' => $shop])->one();

            $store_id = $getToken['store_id'];

            $shopify_token = $getToken['store_token'];

    $data = <<<QUERY
  {
    products (first: 3) {
      edges {
        node {
          id
          title
        }
      }
    }
  }
QUERY;

            $url = "https://".$shop."/admin/api/2022-10/graphql.json";
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            $headers = array(
                "Accept: application/graphql",
                "X-Shopify-Access-Token: " . $shopify_token,
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            $products = curl_exec($curl);
            curl_close($curl);

          print_r($products);
            //$products = json_decode($products,true);
         die;

}

  public function actionGetbox($shopp)
    {

                 $sql = "SELECT * from admin_product limit 1";

                  $commands = Yii::$app->db->createCommand($sql);

                  $qwer= $commands->queryAll();
                
        $result = $qwer[0];

          $width = '';
                        foreach (range($result['min_width'], $result['max_width'], $result['inc_width']) as $number) {
                            $number = number_format((float)$number, 2, '.', '');
                            $width .= '<option value="'.$number.'">'.$number.'</option>';
                        }

                         $height = '';
                        foreach (range($result['min_height'], $result['max_height'], $result['inc_height']) as $number) {
                            $number = number_format((float)$number, 2, '.', '');
                            $height .= '<option value="'.$number.'">'.$number.'</option>';
                        }

        $data = $_GET;

        //$shop = $data["shop"];

        $web_url = Yii::$app->params["WEB_URL"];
		
		$shop = $shopp;
		$getToken = Truequiz::find()->where(['store_shop' => $shop])->one();

        if (!empty($getToken)) {
            $store_id = $getToken["store_id"];

            $shopify_token = $getToken["store_token"];

            $session = Yii::$app->session;

            $session->open();

            $b_name = $session["b_name"];

            $shopifyClient = new ShopifyClient(
                $shop,
                $shopify_token,
                Yii::$app->params["APP_KEY"],
                Yii::$app->params["SECRET_KEY"]
            );

            $all_themes = $shopifyClient->call("GET","/admin" . Yii::$app->params["API_DATE"] . "themes.json");

            $theme_id = "";

            if (!empty($all_themes)) {
                foreach ($all_themes as $theme) {
                    if ($theme["role"] == "main") {
                        $theme_id = $theme["id"];
ob_start();
       $WEB_URL =Yii::$app->params["WEB_URL"];
       $APP_COMPANY_URL =Yii::$app->params["APP_COMPANY_URL"];
	  ?>
<link href="<?php echo $WEB_URL;?>filepond/filepond/filepond.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $WEB_URL;?>filepond/filepond/filepond-plugin-file-poster.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $WEB_URL;?>filepond/pintura/pintura.css" rel="stylesheet" type="text/css" />
<style>
    .form_fields {
        width: 48%;
        display: inline-block;
    }

    .m-rt {
        margin-right: 3.4%;
    }

    .field_sec {
        margin-bottom: 2rem;
        position: relative;
        width: 100%;
        display: flex;
    }

    .field_input {
        padding: 1.5rem;
        appearance: none;
        font-size: 14px;
        width: 100%;
        border: 0;
        border-radius: 8px;
        border: 1px solid;
    }

    .filepond--item > .filepond--file-wrapper {
        background: #0000009c;
        border-radius: 8px;
    }

    .filepond--drop-label {
        background: #000;
        font-weight: bold;
        color: #fff;
        border-radius: 5px;
        font-family: sans-serif;
        min-height: 2.5em !important;
    }

    .filepond--root :not(text) {
        font-size: 20px;
    }

    .filepond--credits {
        display: none !important;
    }

    .filepond--list {
        margin-top: 5px !important;
    }

    .form_submit {
        width: 100%;
    }

    .form_submit .button {
        width: 100%;
        background: #fff;
        color: #000;
        border: 2px solid #000000c4;
        border-radius: 8px;
    }

    .form_submit .button:hover {
        background: #000;
        color: #fff;
    }

    .options_req {
        color: red;
        border: 2px dotted;
        text-align: center;
        padding: 9px;
    }

    .filepond_sec {
        display: none;
    }

    .or_sec {
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        margin: 0;
    }
	.PinturaStage div:empty {
    display: block;
}
.PinturaRangeInput div:empty {
    display: block;
  }
					.mod_{
						display:none;
					}
</style>
<div class="page-width page-width--narrow section-{{ section.id }}-padding">

    <h1 data="wert" class="main-page-title page-title h0">Upload Art</h1>

    <div class="rte">{{ page.content }}</div>

    <div class="col-md-12">
<!--  popup --->
<div class="mod_">
		        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <style>
.img-container {
    position: relative;
    max-width: 700px;
    padding: 2rem 4rem;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: #fff;
    border-radius: 10px;
}
span.img-container-close {
    font-size: 26px;
    background: #000;
    height: 35px;
    text-align: center;
    width: 35px;
    font-family: monospace;
    color: #fff;
    border-radius: 50px;
    position: absolute;
    top: -5px;
    right: -5px;
    cursor: pointer;
}
.img-heading {
    text-align: center;
    font-family: sans-serif;
}
.img-heading h2 {
    color: red;
    text-transform: capitalize;
    margin-top: 0;
}
.img-block-1 {
    border: 1px solid #000;
    margin-bottom: 10px;
    max-width: 550px;
}
.img-block-1  img {
    width: 100%;
    object-fit: cover;
    object-position: center;
}
.img-block-2 {
    display: flex;
    gap: 10px;
    height: 19px;
}
body .img-block-wraper {
    height: unset;
    width: 19px;
    cursor: unset;
    border: unset !important;
}
.img-block-2 div {
    height: 15px;
    width: 15px;
    cursor: pointer;
    border: 1px solid #000;
}
	.mod_ {
    margin-top: 30px;
}
.img-block-2 div:hover{
    border: 2px solid #800080;
}
.img-opt-1 {
    background:#808080;
}
.img-opt-2 {
    background:#fff;
}
.img-opt-3 {
    background: #000;
}
.img-footer {
    margin-top: 12px;
}
.img-footer h6 {
    margin: 5px 0px;
    font-size: 20px;
    color: red;
    text-transform: capitalize;
    font-family: sans-serif;
    border-bottom: 1px solid #000;
}
.img-footer ul {
    padding-left: 20px;
    list-style:disc;
    margin: 5px 0;
    font-family: sans-serif;
}
.img-footer ul li {
    margin-bottom: 3px;
}
 @media screen and (max-width:336px){
    .req-dim{
     letter-spacing: -0.7px;
}
 }
 @media screen and (max-width:600px){
    .img-container{
     padding:2rem 1rem;
}
 }
 .img-container:after {
    height: 100%;
    width: 100%;
    position: fixed;
    top: 0;
    left: 0;
    content: "";
    background: rgb(0,0,0,0.8);
    z-index: -1;
}
span.img-container-close {
    line-height: 1.2;
}
.img-block-1{
     height:270px;
	 width:550px;
}
.img-block-1  img {
    width: 100%;
    object-fit: contain;
    object-position: center;
    height: 100%;
}
div:empty{
    display: block;
}
@media screen and (max-width:600px){
.img-block-1{
    width:450px;
}
}
@media screen and (max-width:500px){
.img-block-1{
    width:350px;
}
}
@media screen and (max-width:400px){
.img-block-1{
    width:300px;
}
}
@media screen and (max-width:350px){
.img-block-1{
    width:250px;
}
}
.img-heading h2 {
    font-weight: bold;
    font-size: 26px;
	letter-spacing: normal;
}
p.req-dim {
    font-weight: bolder;
    color: #000;
    letter-spacing: normal;
    font-size: 17px;
}
p.img-file-name {
    color: #000;
    letter-spacing: normal;
    font-size: 17px;
}
.img-footer h6 {
    line-height: normal;
}
.img-footer ul li {
    color: #000;
    font-size: 18px;
    line-height: normal;
    letter-spacing: normal;
}
.img-footer{
  width:550px;
}
@media screen and (max-width:600px){
.img-footer{
    width:450px;
}
}
@media screen and (max-width:500px){
.img-footer{
    width:350px;
}
}
@media screen and (max-width:400px){
.img-footer{
    width:300px;
}
}
@media screen and (max-width:350px){
.img-footer{
    width:250px;
}
}
.filepond_sec .form_submit .button {
    margin-bottom: 10px;
    background: #000;
    color: #fff;
    border: 2px solid #000;
	font-size: 16px;
}
.filepond_sec input.clearr {
    background: #000;
    color: #fff;
    border: unset;
    margin-left: 5px;
    border-radius: 5px;
    font-size: 16px;
    padding: 10px 27px;
    cursor: pointer;
}
.filepond_sec .field_sec .field_input:focus-visible{
     outline:unset;
     outline-offset:unset;
	 box-shadow:unset;
}
.transparent-background {
    background-image: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4gKwSUNDX1BST0ZJTEUAAQEAAAKgbGNtcwQwAABtbnRyUkdCIFhZWiAH5gALAAkACQACAB9hY3NwQVBQTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9tYAAQAAAADTLWxjbXMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1kZXNjAAABIAAAAEBjcHJ0AAABYAAAADZ3dHB0AAABmAAAABRjaGFkAAABrAAAACxyWFlaAAAB2AAAABRiWFlaAAAB7AAAABRnWFlaAAACAAAAABRyVFJDAAACFAAAACBnVFJDAAACFAAAACBiVFJDAAACFAAAACBjaHJtAAACNAAAACRkbW5kAAACWAAAACRkbWRkAAACfAAAACRtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACQAAAAcAEcASQBNAFAAIABiAHUAaQBsAHQALQBpAG4AIABzAFIARwBCbWx1YwAAAAAAAAABAAAADGVuVVMAAAAaAAAAHABQAHUAYgBsAGkAYwAgAEQAbwBtAGEAaQBuAABYWVogAAAAAAAA9tYAAQAAAADTLXNmMzIAAAAAAAEMQgAABd7///MlAAAHkwAA/ZD///uh///9ogAAA9wAAMBuWFlaIAAAAAAAAG+gAAA49QAAA5BYWVogAAAAAAAAJJ8AAA+EAAC2xFhZWiAAAAAAAABilwAAt4cAABjZcGFyYQAAAAAAAwAAAAJmZgAA8qcAAA1ZAAAT0AAACltjaHJtAAAAAAADAAAAAKPXAABUfAAATM0AAJmaAAAmZwAAD1xtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAEcASQBNAFBtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEL/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wgARCAAsACwDAREAAhEBAxEB/8QAGwAAAwADAQEAAAAAAAAAAAAABAUGAQIDAAf/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAH7KUwYRpbhomAjYLFpkcCs8NBGYFRTBhGluGgohMD8lTmWYgNCiJM5H//EACAQAAEEAgIDAQAAAAAAAAAAAAMAAQIEBRUUNBASMxP/2gAIAQEAAQUCWJ+eR6ip9VaoSIR8aQVmV+WqEueSu+1KtiBWBvfLXrypk2IE9Ih5a03jE/PI9RU+quKFXpvWPTLM5uKFEskGTmGXsr8GIekNoH9kULOX8GX/xAAUEQEAAAAAAAAAAAAAAAAAAABQ/9oACAEDAQE/ARP/xAAUEQEAAAAAAAAAAAAAAAAAAABQ/9oACAECAQE/ARP/xAAoEAABAgQEBQUAAAAAAAAAAAABAAIDEBESITIzcRNSgZGhIiMxQVH/2gAIAQEABj8CT90/pKHtLM9WQ8QRX1LgxAA08qzPRhNDbWEgVWViz+FfBxAFFxYuDAs/hOiNpa4khfA7yfun9JQ9pabeythe2La0arIhvb+Fabeye1ryGhxAC1DIE8qBEnnHMV9r/8QAIxABAAIBAwMFAQAAAAAAAAAAAQARIWGh8SAx0RBBcZGxUf/aAAgBAQABPyGbFNx+uiuUPEcmHtzbtPav5KAEtcHE5Q8SyklBuh+Zwj5mq+8vIGu8Zt8zBglKN95qvvCtT0vsvrrYpuP10VweDktCCrbYbWo3nJweB+UHYLZy8vpLQBoY+WIw3T3l9Jd6ym81Y//aAAwDAQACAAMAAAAQkEkAAgAggkEkkEkgkk//xAAUEQEAAAAAAAAAAAAAAAAAAABQ/9oACAEDAQE/EBP/xAAUEQEAAAAAAAAAAAAAAAAAAABQ/9oACAECAQE/EBP/xAAiEAEAAgEDBAMBAAAAAAAAAAABABEhEFHwMWGhwUGx8dH/2gAIAQEAAT8QnLbTmNunift1nFm1lDAFsKEaosWioSlU+NtJ1gWEjSCoC8baTuQ+pcp+tZZ6JsJnhGzRwMGes5D6lebJKpRp6T8bpy205jbp4n7dOGepRfeAUNtdgjsUqCJkxOGeo1hs6EQBtpLsw4wKCxVvuOEAqRXSdmFECqkq1u0/WP5P/9k=);
    background-color: unset;
    background-repeat: repeat;
    background-size: auto;
}

.light-background {
    background-image: unset;
    background-color: #fff;
}

.dark-background {
    background-image: unset;
    background-color: #000;
}
        </style>
		<script src="https://unpkg.com/@panzoom/panzoom@4.5.1/dist/panzoom.min.js"></script>
      <div class="img-container">
        <span class="img-container-close">x</span>
        <div class="img-heading">
            <h2>Image issues Detected</h2>
            <p class="req-dim">Requested Print Size: 4 inches x 6 inches</p>
            <p class="img-file-name">Myfilename.png</p>
        </div>
        <div class="img-block">
            <div class="img-block-1 ">
                 <img class="panzoom" id="panzoom-element" src="" alt="">
            </div>
            <div class="img-block-2">
               <div class="img-block-wraper a"> <div class="img-opt-1"></div></div>
               <div class="img-block-wraper b"> <div class="img-opt-2"></div></div>
               <div class="img-block-wraper c"> <div class="img-opt-3"></div></div>
              
            </div>

        </div>
        <div class="img-footer">
            <h6>Image problems:</h6>
            <ul></ul>
        </div>
      </div> <script src="" async defer></script> 
	  </div>
<!-- End popup --->
		<input type="hidden" class="btnss" value="<?php echo $result['btn_name']; ?>" font-color="<?php echo $result['btn_color']; ?>" font-size="<?php echo $result['btn_font_size']; ?>"/>
         <form action="<?php echo $APP_COMPANY_URL;?>/shopify/product-tool/?shop=<?php echo $shopp;?>"  method="post" enctype="multipart/form-data" dat="sds">

            <h2>Size of Art</h2>

            <div class="form_fields m-rt">

                <label class="col-form-label">Width in Inches</label>
                <div class="field_sec">
                    <select name="width" class="field_input width_opt" required>
                        <option value="">Select width</option>
                        <?php echo $width;?>
                    </select>
                </div>
            </div>

            <div class="form_fields">

                <label class="col-form-label"> Height in Inches</label>
                <div class="field_sec">

                      <select name="height" class="field_input height_opt" required>
                        <option value="">Select height</option>
                        <?php echo $height;?>
                    </select>
                </div>
            </div>
            <p class="options_req">Width and Height required</p>
            <div class="filepond_sec"> 
		<!-- Corrected vvv -->
                <input type="file" class="filepond" />
		<!-- Corrected ^^^ -->
                <input type="hidden" name="final_image" class="final_image"/>
                <div class="filepondbox"></div>
                <p class="or_sec">OR</p>
                <div class="form_fields_f">

                    <label class="col-form-label"> File URL (as option alternative to file-upload) :</label>
                    <div class="field_sec">
				<div class="pintura-editor"></div>

                        <input type="url" name="file_path" class="field_input fileponds" />
						<input type="button" value="Clear" class="clearr">
                    </div>
					<div class="form_submit">
					<input type="button" class="load_image button submit_add" value="Load image from URL">
					</div>
                </div>
                <div class="form_submit">

                    <input type="submit" class="button submit_add" disabled="disabled" name="submit_add" value="Add">

                </div>
            </div>
        </form>
		
        {% schema %}
        {
        "name": "Product Tool",
        "settings": [],
        "presets": [
        {
        "name": "Product Tool Section",
        "category": "ADVANCED LAYOUT"
        }
        ]
        }
        {% endschema %}

    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo $WEB_URL;?>filepond/filepond/filepond.js"></script>
<script src="<?php echo $WEB_URL;?>filepond/filepond/filepond-plugin-file-poster.js"></script>
<script src="<?php echo $WEB_URL;?>filepond/filepond/filepond-plugin-file-validate-type.js"></script>
<script src="<?php echo $WEB_URL;?>filepond/filepond-plugin-image-editor/FilePondPluginImageEditor.js"></script>
<script type="module">
import {
	 openDefaultEditor ,
	openEditor,
	processImage,
	createDefaultImageReader,
	createDefaultImageWriter,
	createDefaultImageOrienter,

	// Only needed if loading legacy image editor data
	legacyDataToImageState,

	// Import the editor default configuration
	getEditorDefaults,
	createDefaultShapePreprocessor,
	// Import the default configuration for the markup editor and finetune plugins
	markup_editor_defaults,
	plugin_finetune_defaults,
} from "{{ 'pintura.js' | asset_url }}";
FilePond.registerPlugin(
	FilePondPluginFileValidateType,
	FilePondPluginImageEditor,
	FilePondPluginFilePoster
);

const apiBaseURL = 'https://test-api-ubzqe5vs2q-uc.a.run.app/api/v1';
// string interposlation
const assetBaseURL = `${apiBaseURL}/asset`;

 const buttonEditImage = document.querySelector('.load_image');
    buttonEditImage.addEventListener('click', () => {
					var es=$(".form_fields_f .field_input").val();
					let w = $(".width_opt").val();
					let h = $(".height_opt").val();
        // Edit the selected file
        const editor = openDefaultEditor({
            imageCropAspectRatio: 1,
            src: es,
			 imageWriter: {
            store: {
                // Where to post the files to
               url: `${assetBaseURL}/store`,

                // Which fields to post
                dataset: (state) => [
				console.log(state),
                    ['image', 
					state.dest, state.dest.name],
                    ['imagecode', 'check'],
                    ['height', h],
                    ['width', w],
                ],
            },
        },
        });
		
        });
const API_KEY = 'eyJhbGciOiJSUzI1NiIsICJraWQiOiAiMSIgfQ.eyJzdWIiOiJXVS1pVkI1M1M2ZUZaTVhkUFNudkx3IiwgImlhdCI6ICIxNjY4MTg0OTY1IiwgImlzcyI6ICJkc2tleWFkbWluIiwgImF1ZCI6ICJsaV9hcGkiIH0.GakXb_6qMEfWTJ5XJR9xGAB0Aq5aqyp7iSCl0clQC1w5Z7FB-tkXhKODJNXrPSvUkCKg8uvw18qH9jsrrNyFynpvPzwOXLvNBtHt6geM3fvT6y-ZKKojfgc4_w-tHBO9AYlf4ylANg0Z7uVE--fVQq1WbyUEHneCuH6E21bHySS94zRv9CLM1cMhwJkFrlX3vyyD7Pqz1Rj5bUO6p35-97wcAXWMCj2ItvVYEQzXbqNfPECpGAacnE_R0ZpOsfD8u9NJ6K9SblNzUinW44WUO4KSy_oGaNNC7Bbf426PstKgXdXf8U5wFbs5pYPGsrg146QvVBb8S3YQxjiCBMRtstmNaSDfnxRiKl6VqVEkzSxghLgJ27OV_UJwMLRYU5VLmC3e2uRaQzUqbuYV9LLR53PVWYwD0obEbyQ_u7C1HLL1rSPhZt8dSR-snW0OIZpUHIWXieRbf5RodYa9HUexpsQgmDTcxay0RfkU1pOR59wDOCs7-VUj3RggTvhoVMFu';

function getAuthHeader() {
	return {
	'X-AUTH-TOKEN': API_KEY
	};
}

console.log("assetBaseURL"+assetBaseURL);

/**
* @w width
* @h height
**/

function get_filepond(w, h){
	const filepondOptions = {
		// you can use this if you need to be updated with the file selection
		// -- it is NOT needed, however, for the image editing nor the upload
		//
		// onupdatefiles: (files: FilePondFile[]) => {
		//
		// },
		allowMultiple: false,
		maxFiles: 1,
		chunkUploads: false,
		credits: false,
		instantUpload: true,
		allowProcess: true,
		name: "image",
		server: {
			process: {
				url: `${assetBaseURL}/store`,
				method: 'POST',
				withCredentials: true,
				headers: getAuthHeader(),
				timeout: 10000,
				//dataType: "json", 
				ondata: (formData) => {
					formData.append('imagecode', 'check');
					formData.append('width', w);
					formData.append('height', h);
					setTimeout(function(){
					get_issues(w, h);
					},2000);
					console.log(formData);
					return formData;
				},
				onload: (json) => {
					let response;
					try { response = JSON.parse(json); } catch (e) { }
					if (response?.status !== 'OK') {
						// setImageInfo(null);
						return;
					}

					const {
						assetIdentifier: imageId,
						imageInfo: imageDetails
					} = response;

					const {
						errors: imageIssues = [],
						mimeType,
						fileExtension
					} = imageDetails || {};

					// wrong
					//const imageUrlBase = 'https://test-api-ubzqe5vs2q-uc.a.run.app/api/v1/id/${imageId}';
					// old way
					//const imageUrlBase = assetBaseURL + '/id/' + imageId;
					// back-quote interpolation
					const imageUrlBase = `${assetBaseURL}/id/${imageId}`;
					jQuery('.final_image').val(imageUrlBase);
					jQuery('.submit_add').removeAttr('disabled');
					const previewImages = {
					    'uploaded': imageUrlBase
					};

					imageIssues.forEach((ii) => {
						if (ii.hasPreview && ii.code) {
							//previewImages['${ii.code}'] = '${imageUrlBase}?t=preview&code=${ii.code}';
							previewImages[`${ii.code}`] = `${imageUrlBase}?t=preview&code=${ii.code}`;
						}
					});

					const errorMessages = imageIssues;
					const imageInfo = {
						mimeType,
						fileExtension,
						//originalImage: '${imageUrlBase}?t=original',
						originalImage: `${imageUrlBase}?t=original`,
						//thumbImage: '${imageUrlBase}?t=thumb',
						thumbImage: `${imageUrlBase}?t=thumb`,
						//currentImage: '${imageUrlBase}',
						currentImage: `${imageUrlBase}`,
						previewImages,
						errorMessages
					};
				// setImageInfo(imageInfo);
				var thumb='<input type="hidden" name="thumb_img" class="thumb_img" value="'+imageInfo.thumbImage+'">';
					$(".final_image").after(thumb);
				if(imageInfo.errorMessages[0] != undefined){	
				$(".img-footer ul li").remove();
					 var er_one=imageInfo.errorMessages[0].message;
					 var htm='<li class="a">'+er_one+'</li>';
					 $(".img-footer ul").append(htm);
				}
				 if(imageInfo.errorMessages[1] != undefined){
				    var er_two=imageInfo.errorMessages[1].message;
					 var htm1='<li class="b">'+er_two+'</li>';
					 $(".img-footer ul").append(htm1);
				}
				if(imageInfo.errorMessages[2] != undefined){
					 var er_thr=imageInfo.errorMessages[2].message;
					var htm2='<li class="c">'+er_thr+'</li>';
					 $(".img-footer ul").append(htm2);
				}
					return imageId;
				}
			},

			revert: null,
		},	
		filePosterMaxHeight: 256,
		allowImageEditor: true,
		imageEditorInstantEdit: true,
		imageEditorAllowEdit: true,
		imageEditorAfterWriteImage: ({ src, dest, imageState }) =>{
			return new Promise((resolve, reject) => {
			processImage(src, {
			imageReader: createDefaultImageReader(),
			imageWriter: createDefaultImageWriter({
			targetSize: {
			width: 128, 
			height: 128,
			fit: 'cover', 
			},
			}),
			imageState,
			}).then((thumb) =>
			resolve([
			{ name: 'input_', file: src },
			{ name: 'output_', file: dest },
			{ name: 'thumb_', file: thumb.dest },
			])
			)
			.catch(reject);
			})
		},
		imageEditor: {
		...getEditorDefaults(),
		legacyDataToImageState: legacyDataToImageState,
		createEditor: openEditor,
		imageReader: [
		createDefaultImageReader,
		{
		// createDefaultImageReader options here
		annotateEnableDropImagePreset: false,
		}, 
		],

		// required
		imageWriter: [
			createDefaultImageWriter,
			{
			    targetSize: {
                width: 256,
                height: 256,
            },
			},
			],

			// Used to poster and output images, runs an invisible "headless" editor instance.
			imageProcessor: processImage,

			// Pintura Image Editor options
			editorOptions: {
				...getEditorDefaults(),
				// onLoad: handleEditorLoad,
				// // This will set a square crop aspect ratio
				//
				// THIS LINE NOT WORKING CORRECTLY
				//imageCropAspectRatio: $(".width_opt").val()/$(".height_opt").val(),
				imageCropAspectRatio: 1,
				// This handles complex shapes like arrows / frames
				shapePreprocessor: createDefaultShapePreprocessor(),
				// The icons and labels to use in the user interface (required)
				// locale: {
				  //   ...locale_en_US,
				//     ...plugin_crop_locale_en_US,
			//  ...plugin_finetune_locale_en_US,
			//	     ...plugin_annotate_locale_en_US,
				//     ...markup_editor_locale_en_US,

				//     // change text on button
				     //labelButtonExport: 'Upload'
			//	}
			}
		}
	};
	FilePond.create(document.querySelector('.filepond'),filepondOptions);
}

function get_issues(w, h){
		var ts=jQuery('.filepond--file-poster img').attr('src');
					$(".req-dim").text("Requested Print Size: "+w+" inches x "+h+" inches");
		var name=$(".filepond--file-wrapper legend").text();
				$(".img-file-name").text(name);
					$(".mod_").show();
					  $(".img-block-wraper.a").trigger("click");
				    $(".img-block-1 img").attr("src",ts);
				$(".col-md-12 form,h1.main-page-title.page-title.h0").hide();
}
			$(".img-container-close").click(function(){
					$(".mod_").hide();
					$(".col-md-12 form,h1.main-page-title.page-title.h0").show();
			});
			$(".img-block-wraper.a").click(function(){
				$(".img-block-1").removeClass("dark-background");
				$(".img-block-1").removeClass("light-background");
					$(".img-block-1").addClass("transparent-background");
			});
			$(".img-block-wraper.b").click(function(){
				$(".img-block-1").removeClass("dark-background");
				$(".img-block-1").removeClass("transparent-background");
					$(".img-block-1").addClass("light-background");
			});
			$(".img-block-wraper.c").click(function(){
				$(".img-block-1").removeClass("light-background");
				$(".img-block-1").removeClass("transparent-background");
				$(".img-block-1").addClass("dark-background");
			});
$(".width_opt,.height_opt").on("change",function(){
	if($(".width_opt").val() != '' && $(".height_opt").val() != ''){
		let w = $(".width_opt").val();
		let h = $(".height_opt").val();
		$(".options_req").hide();
		$(".filepond_sec").show();
		get_filepond(w, h);
	}
});
      </script>
	  <script>
const elem = document.getElementById('panzoom-element');
        const panzoom = Panzoom(elem);
        const parent = elem
parent.addEventListener('wheel', panzoom.zoomWithWheel);
      </script>
      <script>
	  setInterval(function(){
		  var nam=$(".btnss").attr("value");
		  var colr=$(".btnss").attr("font-color");
		  var size=$(".btnss").attr("font-size");
		  if(nam != ""){
			$(".filepond--drop-label label").text(nam);  
			$(".filepond--drop-label").css("cursor","pointer");  
		  }
		  if(colr != ""){
			  $(".filepond--drop-label").css("background-color",colr);
		  }
		  if(size != ""){
			  $(".filepond--drop-label label").css("font-size",size);
		  }
		  var df=$(".form_fields_f .field_input").val();
		if(df !== ""){
		$(".filepond--root,.or_sec").hide();
		$(".clearr,.load_image").show();
		}else{
		$(".filepond--root,.or_sec").show();
		$(".clearr,.load_image").hide();
		}
		$(".clearr").click(function(){
		$(".form_fields_f .field_input").val("")
		});

		  },0);
      </script>
      <script>
	   $(document).ready(function(){
		  $(".load_image").click(function(){
			  
			    });
	  });
      </script>
      <?php

      $value = ob_get_contents();
ob_end_clean();

                        $arg = [
                            "asset" => [
                                "key" => "sections/main-page-lookup.liquid",

                                "value" => $value,
                            ],
                        ];

                        $status = $shopifyClient->call(
                            "PUT",
                            "/admin" .
                                Yii::$app->params["API_DATE"] .
                                "/themes/" .
                                $theme_id .
                                "/assets.json",
                            $arg
                        );

                        
                        $value = '{

                          "sections": {
							"wrapper": "div#div_id.div_class[attribute-one=value]",	
                            "main": {

                              "type": "main-page-lookup"

                            }

                          },

                          "order": [

                            "main"

                          ]

                        }';

                        $arg = [
                            "asset" => [
                                "key" => "templates/page.lookup.json",

                                "value" => $value,
                            ],
                        ];

                        $status = $shopifyClient->call(
                            "PUT",
                            "/admin" .
                                Yii::$app->params["API_DATE"] .
                                "/themes/" .
                                $theme_id .
                                "/assets.json",
                            $arg 
                        );
                      print_r($status);

                        // $arg = [
                        //     "custom_collection" => [
                        //         "title" => "Project Tool",
                        //     ],
                        // ];

                        // $status = $shopifyClient->call(
                        //     "POST",
                        //     "admin/api/2021-10/custom_collections.json",
                        //     $arg
                        // ); 
                      
                    }
                } 
            }

    
            exit();
        }
    }

public function actionTranstions(){
	?>
	<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
	<div class="abc"></div>
	<script>
	var settings = {
  "url": "https://product-tool.myshopify.com/admin/api/2022-10/graphql.json",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/json",
    "X-Shopify-Access-Token": "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"
  },
  "data": JSON.stringify({
    "query": "mutation AppSubscriptionCreate($name: Super Duper Recurring Plan, $lineItems:[{plan:{appRecurringPricingDetails: {price: {amount: 10,currencyCode: USD},interval: EVERY_30_DAYS}}}], $returnUrl: https://product-tool.myshopify.com/){appSubscriptionCreate(name: $name, returnUrl: $returnUrl, lineItems: $lineItems) { userErrors { field message } appSubscription { id } confirmationUrl } }",
    "variables": {
      "name": "Super Duper Recurring Plan",
      "returnUrl": "https://product-tool.myshopify.com/",
      "lineItems": [
        {
          "plan": {
            "appRecurringPricingDetails": {
              "price": {
                "amount": 10,
                "currencyCode": "USD"
              },
              "interval": "EVERY_30_DAYS"
            }
          }
        }
      ]
    }
  }),
};

$.ajax(settings).done(function (response) {
 console.log(response);
});
	</script>
	<?php
}
}