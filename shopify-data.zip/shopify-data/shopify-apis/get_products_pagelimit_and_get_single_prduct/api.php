<?php
//get single product api 

$prdc_data = $shopifyClient->call('GET', '/admin'.Yii::$app->params['API_DATE'].'products/'.$product_id.'.json?fields=variants');




// get products in page limit wise

include "Shopify.php";
$shopify = new Shopify();
$store_token = "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";
$shop = "order-db.myshopify.com";
$app_version = "2023-04";
$store_id = "120";

				$store = "order-db.myshopify.com";
				$apiKey = "391958f56c3f84ea6bbd2b0d698c16dd";
				$password = "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 ";

				// Number of products per page
				$limit = 47;
				//$products = $shopify->call($shop,"GET","/admin/api/" . $app_version . "/collections/164500504635/products.json",$store_token);
				//print_r($products);

				// Prepare the API URL
				$url = "https://$store/admin/api/2023-04/collections/164501585979/products.json?limit=$limit";
				//&page_info=eyJsYXN0X2lkIjo2OTA2NTM0MDM1NTE1LCJsYXN0X3ZhbHVlIjoiQWxsIEJsYWNrIiwiZGlyZWN0aW9uIjoibmV4dCJ9
				// Initialize cURL session
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				curl_setopt($ch, CURLOPT_USERPWD, "$apiKey:$password");
				curl_setopt($ch, CURLOPT_HEADER, true);

				// Execute the cURL request
				$response = curl_exec($ch);

				// Check if the request was successful
				if ($response === false) {
					die(curl_error($ch));
				}

		// Get the response headers
		$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$responseHeaders = substr($response, 0, $headerSize);

		// Close cURL session
		curl_close($ch);

		// Parse the Link header to extract URLs
		$links = [];
		$pattern = '/<([^>]*)>; rel="([^"]*)"/';
		if (preg_match_all($pattern, $responseHeaders, $matches, PREG_SET_ORDER)) {
			foreach ($matches as $match) {
				$url = $match[1];
				$rel = $match[2];
				$links[$rel] = $url;
			}
		}

		// Use the extracted URLs as needed
		if (isset($links["next"])) {
			$nextUrl = $links["next"];
			echo "Next Page URL: $nextUrl<br>";
		}

		if (isset($links["previous"])) {
			$prevUrl = $links["previous"];
			echo "Previous Page URL: $prevUrl<br>";
		}