<?php 
error_reporting(E_ALL);
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Headers: Content-Type, X-Auth-Token, Authorization, Origin');
header('Content-Type: application/json'); // Set the content type to JSON

include('shopify.php');
$shopify = new Shopify();

$store_token = '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';
$shop = 'b33f57.myshopify.com';
$app_version = "2023-07";
$percent = 2;

$products = $_POST;
$product_id = ($products['product_id']);
//echo '<pre>';
//print_r($product_id);
//echo '</pre>';
$productIds = explode(',', $product_id);
//print_r($productIds);
$createdVariants = [];

foreach ($productIds as $data) {
//print_r($data);
    list($productId, $price) = explode('_', $data);
    $priceInput = number_format($price, 2, '.', '');
    $varientInput = "Variant ".$priceInput;
//print_r($productId);
    // Get the list of variants
    $varient_count = $shopify->call($shop,'GET', "/admin/api/".$app_version."/products/".$productId."/variants/count.json",$store_token);
    $varient_get = $shopify->call($shop,'GET', "/admin/api/".$app_version."/products/".$productId."/variants.json",$store_token);

    $existingVariant = null;
    $variantId = '';

    if (isset($varient_get)) {
     
        foreach ($varient_get as $variant) {
          
            if ($varient_count == 100) {
                $variantId = $variant['id'];
                $shopify->call($shop,'DELETE', "/admin/api/".$app_version."/products/".$productId."/variants/".$variantId.".json",$store_token);
            }
            if (isset($variant['title']) && $variant['title'] === $varientInput) {
                $existingVariant = $variant;
             
                $variantId = $variant['id'];
              
                break;
            }
        }
    }

    if ($existingVariant !== null) {
        $createdVariants[] = [
            'status' => '0',
            'variantId' => $variantId
        ];
    } else {
        $varient_array = array(
            "variant" => array(
                "title"      => 'Dynamic Product',
                "option1"    => $varientInput,
                "price"      => $price,
                "weight"     => '',
                "inventory_management"  => null,
                "sku" => 'Dynamic'
            )
        );
        $varient = $shopify->call($shop,'POST', "/admin/api/".$app_version."/products/".$productId."/variants.json",$store_token,$varient_array);

        if(isset($varient['id']) && $varient['id'] != ''){
            $createdVariants[] = [
                'status' => '1',
                'variantId' => $varient['id']
            ];
        }
    }
}

echo json_encode($createdVariants);
?>
