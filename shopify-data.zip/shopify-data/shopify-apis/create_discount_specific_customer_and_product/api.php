<?
//create a discount for specific product and specific customer

$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => 'https://'.$shop.'/admin/api/2023-04/graphql.json',
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => '',
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => 'POST',
				  CURLOPT_POSTFIELDS =>'{
				"query": "mutation discountCodeBasicCreate($basicCodeDiscount: DiscountCodeBasicInput!) { discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) { codeDiscountNode { codeDiscount { ... on DiscountCodeBasic { title codes(first: 10) { nodes { code } } startsAt endsAt customerSelection { ... on DiscountCustomerAll { allCustomers } } customerGets { value { ... on DiscountPercentage { percentage } } items { ... on AllDiscountItems { allItems } } } appliesOncePerCustomer } } } userErrors { field code message } } }",
				 "variables": {
					"basicCodeDiscount": {
					  "title": "'.$dis_count.'",
					  "code": "'.$dis_count.'",
					  "startsAt": "2022-06-21T00:00:00Z",
					  "endsAt": "2025-09-21T00:00:00Z",
					  "customerSelection": {
					  "customers": {
						"add": [
						  "gid://shopify/Customer/'.$customer_id.'"
						],
						"remove": [
						  "gid://shopify/Customer/6134470287931"
						]
					  }
					  },
					  "customerGets": {
						"value": {
						  "percentage": 0.'.$deci.'
						},
						"items": {
							"products": {
								  "productsToAdd": ["gid://shopify/Product/'.$product_id.'"]
										}
						}
					  },
						"combinesWith":{
							"productDiscounts": true
									},
					  "appliesOncePerCustomer": false
					}
				  }
				}',
				  CURLOPT_HTTPHEADER => array(
					'Content-Type: application/json',
					'X-Shopify-Access-Token: '.$shopify_token.''
				  ),
				));

			$response = curl_exec($curl);

			curl_close($curl);

//get discount id  specific product and specific customer

		
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => 'https://order-db.myshopify.com/admin/api/2023-01/discount_codes/lookup.json?code='.$dis_count,
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => '',
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => 'GET',
				  CURLOPT_HTTPHEADER => array(
					'X-Shopify-Access-Token: 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'
				  ),
				));
				$response = curl_exec($curl);
				curl_close($curl);
				$decode=json_decode($response);
				$rs=$decode->discount_code;
				$price_rule_id=$rs->price_rule_id;



//create a discount for all products and all customers

	$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => 'https://'.$shop.'/admin/api/2023-04/graphql.json',
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => '',
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 0,
				  CURLOPT_FOLLOWLOCATION => true,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => 'POST',
				  CURLOPT_POSTFIELDS =>'{
				"query": "mutation discountCodeBasicCreate($basicCodeDiscount: DiscountCodeBasicInput!) { discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) { codeDiscountNode { codeDiscount { ... on DiscountCodeBasic { title codes(first: 10) { nodes { code } } startsAt endsAt customerSelection { ... on DiscountCustomerAll { allCustomers } } customerGets { value { ... on DiscountPercentage { percentage } } items { ... on AllDiscountItems { allItems } } } appliesOncePerCustomer } } } userErrors { field code message } } }",
				 "variables": {
					"basicCodeDiscount": {
					  "title": "'.$dis_count.'",
					  "code": "'.$dis_count.'",
					  "startsAt": "2022-06-21T00:00:00Z",
					  "endsAt": "2025-09-21T00:00:00Z",
					  "customerSelection": {
					  "all": true
					  },
					  "customerGets": {
						"value": {
						  "percentage": 0.'.$deci.'
						},
						"items": {
							"products": {
								  "productsToAdd": ["gid://shopify/Product/'.$product_id.'"]
										}
						}
					  },
						"combinesWith":{
							"productDiscounts": true
									},
					  "appliesOncePerCustomer": false
					}
				  }
				}',
				  CURLOPT_HTTPHEADER => array(
					'Content-Type: application/json',
					'X-Shopify-Access-Token: '.$shopify_token.''
				  ),
				));

			$response = curl_exec($curl);

			curl_close($curl);
			
			
