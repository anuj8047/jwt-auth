public function cartDiscount(Request $request)
{
    $client = new Client();
    $shop_name = 'https://liquor-store-nyc.myshopify.com';
    $token = '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';
    $webhookContent = file_get_contents('php://input');
    $decode_data = json_decode($webhookContent, true);
    $cart_data = $decode_data['line_items'];
    
    $customCollectionsResponse = ''; 

   // foreach ($cart_data as $item) {
        $item_id = $item['id'];
        
        try {
            $response = $client->get($shop_name . "/admin/api/2024-04/variants/" . $item_id . ".json", [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-Shopify-Access-Token' => $token,
                ]
            ]);

            // Collect response data
            $customVariantResponse = json_decode($response->getBody(), true);
          	$check_sale_price=$customVariantResponse['variant']['compare_at_price'];
          if($check_sale_price == null && $check_sale_price == ''){
              $v_id=$customVariantResponse['variant']['id'];
             $product_id=$customVariantResponse['variant']['product_id'];
            $rand = rand(1,99999);
			$dis_count = "CHEERS" . $rand;
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           /* $curl = curl_init();

          curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://liquor-store-nyc.myshopify.com/admin/api/2024-04/graphql.json',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
          "query": "mutation discountAutomaticBasicCreate($automaticBasicDiscount: DiscountAutomaticBasicInput!) { discountAutomaticBasicCreate(automaticBasicDiscount: $automaticBasicDiscount) { automaticDiscountNode { id automaticDiscount { ... on DiscountAutomaticBasic { startsAt endsAt minimumRequirement { ... on DiscountMinimumSubtotal { greaterThanOrEqualToSubtotal { amount currencyCode } } } customerGets { value { ... on DiscountAmount { amount { amount currencyCode } appliesOnEachItem } } items { ... on AllDiscountItems { allItems } } } } } } userErrors { field code message } } }",
           "variables": {
              "automaticBasicDiscount": {
                "title": "$10 off all orders over $200 during the summer of 2022",
                "startsAt": "2022-06-21T00:00:00Z",
                "endsAt": "2025-09-25T00:00:00Z",
                "minimumRequirement": {
                  "subtotal": {
                    "greaterThanOrEqualToSubtotal": 1
                  }
                },
                "customerGets": {
                  "value": {
                              "percentage": 0.1
                          },
                  "items": {
                   "products": {
                       "productVariantsToAdd": ["gid://shopify/ProductVariant/42799801991340"]
                                }
                  }
                }
              }
            }
          }',
            CURLOPT_HTTPHEADER => array(
              'Content-Type: application/json',
              'X-Shopify-Access-Token: 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'
            ),
          ));

          $response = curl_exec($curl);

          curl_close($curl);
          echo $response;
*/
            //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          }
        } catch (\Exception $e) {
            // Handle exception (e.g., log it)
            Log::error('Error fetching variant: ' . $e->getMessage());
        }
   // }

    $filePath = storage_path('app/pro_arr.txt'); // Use storage path for better practice
    file_put_contents($filePath,'ghfh'); // Use file_put_contents for simplicity

    return response()->json(['status' => 'success', 'message' => 'Data saved successfully!']);
}