<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true ");
$productTitle='Strap-Bilfold Wallet';
$graphqlQuery =<<<QUERY
  {
    products (first:3,query: "$productTitle") {
      edges {
        node {
          id
          title
        }
      }
    }
  }
QUERY;
 $url = "https://order-db.myshopify.com/admin/api/2023-07/graphql.json";
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $graphqlQuery);
            $headers = array(
                "Content-Type: application/graphql",
                "X-Shopify-Access-Token: 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",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            $products = curl_exec($curl);
            curl_close($curl);
          print_r($products);