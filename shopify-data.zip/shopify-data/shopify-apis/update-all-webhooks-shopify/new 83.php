<?php
include "shopify.php";
include('config.php');
$shopify = new Shopify();
$api_secret_key = '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';
$shop = 'compressioncarede.myshopify.com';
$headers = getallheaders();
	$webhook = fopen("php://input", "rb");
	$webhook_content = "";

	while (!feof($webhook)) {
			$webhook_content.= fread($webhook, 4096);
	}
	fclose($webhook);
	$pro_arr = json_decode($webhook_content, true);
		
	$myfile = fopen("webhook_update.txt", "w") or die("Unable to open file!");
	fwrite($myfile, print_r($pro_arr,true));
	fclose($myfile);
           $id=$pro_arr['id'];
           $title=$pro_arr['title'];
          	$img=$pro_arr['image']['src'];
          if(empty($img)){
          $img="empty";
          }
           $url=$pro_arr['handle'];
           $curl = curl_init();

          curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://'.$shop.'/admin/api/2023-01/products/'.$id.'/metafields.json',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
              'X-Shopify-Access-Token: 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'
            ),
          ));

          $response = curl_exec($curl);

          curl_close($curl);
          $rt=json_decode($response);
          $data=$rt->metafields;
           foreach($data as $key=>$m_data){
             //echo"<pre>";
          // print_r($data);
          //  echo"</pre>";
           //  die;
          	if($m_data->key == 'ccl'){
              $ccl=$m_data->value;
            
            }
           	if($m_data->key == 'cA_min'){
             $ca_min=$m_data->value;
            }
           	if($m_data->key == 'cA_max'){
             $ca_max=$m_data->value;
            }
           	if($m_data->key == 'cB_min'){
             $cb_min=$m_data->value;
            }
           	if($m_data->key == 'cB_max'){
             $cb_max=$m_data->value;
            }
           	if($m_data->key == 'cY_min'){
             $cy_min=$m_data->value;
            }
           	if($m_data->key == 'cY_max'){
             $cy_max=$m_data->value;
            }
           	if($m_data->key == 'cC_min'){
             $cc_min=$m_data->value;
            }
           	if($m_data->key == 'cC_max'){
             $cc_max=$m_data->value;
            }
           	if($m_data->key == 'topband'){
             $topband=$m_data->value;
            }
           	if($m_data->key == 'toe'){
             $toe=$m_data->value;
            }
            if($key == 4){
              $ctype=$m_data->value;
            }
             //
             if($m_data->key == 'cE_min'){
              $cE_min=$m_data->value;
            }
              if($m_data->key == 'cE_max'){
              $cE_max=$m_data->value;
            }
              if($m_data->key == 'lF_max'){
              $lF_max=$m_data->value;
            }
             if($m_data->key == 'lF_min'){
              $lF_min=$m_data->value;
            }
             if($m_data->key == 'lA_max'){
              $IA_max=$m_data->value;
            }
             if($m_data->key == 'lA_min'){
              $IA_min=$m_data->value;
            }
              if($m_data->key == 'lZ_min'){
              $IZ_min=$m_data->value;
            }
              if($m_data->key == 'lZ_max'){
              $IZ_max=$m_data->value;
            }
              if($m_data->key == 'lG_max'){
              $IG_max=$m_data->value;
            }
              if($m_data->key == 'lG_min'){
              $IG_min=$m_data->value;
            }
              if($m_data->key == 'lD_max'){
              $ID_max=$m_data->value;
            }
              if($m_data->key == 'lD_min'){
              $ID_min=$m_data->value;
            }
              if($m_data->key == 'cG_max'){
              $cG_max=$m_data->value;
            }
              if($m_data->key == 'cG_min'){
              $cG_min=$m_data->value;
            }
              if($m_data->key == 'cF_max'){
              $cF_max=$m_data->value;
            }
              if($m_data->key == 'cF_min'){
              $cF_min=$m_data->value;
            }
              if($m_data->key == 'cD_max'){
              $cD_max=$m_data->value;
            }
              if($m_data->key == 'cD_min'){
              $cD_min=$m_data->value;
            }
              if($m_data->key == 'cB1_max'){
              $cB1_max=$m_data->value;
            }
              if($m_data->key == 'cB1_min'){
              $cB1_min=$m_data->value;
            }
           }
//print_r($id);
          
          
        // if($id == '8409760006470'){
          // print_r($ctype);
         //   echo'<br>';

             $sql ="select * FROM shopify_products where product_id ='" .$id ."'";
            $row = $mysqli->query($sql);
            $exist = $row->fetch_assoc();
            if(!empty($exist)){
              $sqll = "UPDATE shopify_products 
             SET `style_val` = '$ctype', 
                 `ccl` = '$ccl',
                 `ca_min` = '$ca_min',
                 `ca_max` = '$ca_max',
                 `cb_min` = '$cb_min',
                 `cb_max` = '$cb_max',
                 `cy_min` = '$cy_min',
                 `cy_max` = '$cy_max',
                 `cc_min` = '$cc_min',
                 `cc_max` = '$cc_max',
                 `topband_default` = '$topband',
                 `toe_default` = '$toe',
                 `ce_min` = '$cE_min',
                 `ce_max` = '$cE_max',
                 `if_min` = '$lF_min',
                 `if_max` = '$lF_max',
                 `ia_max` = '$IA_max',
                 `ia_min` = '$IA_min',
                 `iz_min` = '$IZ_min',
                 `iz_max` = '$IZ_max',
                 `ig_min` = '$IG_min',
                 `ig_max` = '$IG_max',
                 `id_min` = '$ID_min',
                 `id_max` = '$ID_max',
                 `cg_min` = '$cG_min',
                 `cg_max` = '$cG_max',
                 `cf_min` = '$cF_min',
                 `cf_max` = '$cF_max',
                 `cd_min` = '$cD_min',
                 `cd_max` = '$cD_max',
                 `cb1_min` = '$cB1_min',
                 `cb1_max` = '$cB1_max'
             WHERE product_id = '$id'";
					$row = $mysqli->query($sqll);
               echo $id;
              echo "<br>";
          //  }
         }