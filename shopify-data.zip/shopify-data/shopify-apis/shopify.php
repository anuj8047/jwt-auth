<?php
class Shopify {

	
	public function curlAppendQuery($url, $query) {
		if (empty($query))
			return $url;
		if (is_array($query)) 
			return "$url?" . http_build_query($query);
		else
			return "$url?$query";
	}

	public function curlSetopts($ch, $method, $payload, $request_headers) {
			curl_setopt($ch, CURLOPT_HEADER, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
			curl_setopt($ch, CURLOPT_USERAGENT, 'ohShopify-php-api-client');
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 90);
			curl_setopt($ch, CURLOPT_TIMEOUT, 90);

			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
			if (!empty($request_headers))
				curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);

			if ($method != 'GET' && !empty($payload)) {
				if (is_array($payload))
					$payload = http_build_query($payload);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
			}
	}
		
	public function curlParseHeaders($message_headers) {
			$header_lines = preg_split("/\r\n|\n|\r/", $message_headers);
			$ff=explode(' ', trim(array_shift($header_lines)), 2);
			$headers = array();
			list(, $headers['http_status_code'], $headers['http_status_message']) = explode(' ', trim(array_shift($header_lines)), 3);
			foreach ($header_lines as $header_line) {
				list($name, $value) = explode(':', $header_line, 2);
				$name = strtolower($name);
				$headers[$name] = trim($value);
			}
			return $headers;
	   }
		
	public function curlHttpApiRequest($method, $url, $query = '', $payload = '', $request_headers = array()) {
		$url = $this->curlAppendQuery($url, $query);
		$ch = curl_init($url);
		$this->curlSetopts($ch, $method, $payload, $request_headers);
		$response = curl_exec($ch);
		$errno = curl_errno($ch);
		$error = curl_error($ch);
		curl_close($ch);

		ini_set('display_errors',1);
		if ($errno){
		   return  'error';
			
		}
		list($message_headers, $message_body) = preg_split("/\r\n\r\n|\n\n|\r\r/", $response, 2);
		$last_response_headers = $this->curlParseHeaders($message_headers);
	
		return $message_body;
	}
	
	
	public function call($shop,$method, $path,$access_token, $params = array(), $request_headers = array() ) {
			$baseurl = "https://".$shop."/";

			$url = $baseurl . ltrim($path, '/');
			$query = in_array($method, array('GET', 'DELETE')) ? $params : array();
			$payload = in_array($method, array('POST', 'PUT')) ? json_encode($params) : array();
			$request_headers = in_array($method, array('POST', 'PUT')) ? array("Content-Type: application/json; charset=utf-8", 'Expect:') : array();

			// add auth headers
			$request_headers[] = 'X-Shopify-Access-Token: ' . $access_token;
			

			$response = $this->curlHttpApiRequest($method, $url, $query, $payload, $request_headers);  
			
			$response = json_decode($response, true);
			if (isset($response['errors']) ){
				return $response;
			}

		return (is_array($response) and ( count($response) > 0)) ? array_shift($response) : $response;
	}
	
	
	public function graphql($query=array(),$shop,$token,$version){
		$url='https://'.$shop. '/admin/api/'.$version.'/graphql.json';

		$curl=curl_init($url);

		curl_setopt($curl,CURLOPT_HEADER,true);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($curl,CURLOPT_FOLLOWLOCATION,true);
		curl_setopt($curl,CURLOPT_MAXREDIRS,10);

		$headers[]="";

		$headers[]="Content-Type: application/json";

		if(!is_null($token)){
			$headers[]="X-Shopify-Access-Token: ".$token;
			curl_setopt($curl,CURLOPT_HTTPHEADER,$headers);
		}


		curl_setopt($curl,CURLOPT_POSTFIELDS,json_encode($query));
		curl_setopt($curl,CURLOPT_POST,true);

		$response= curl_exec($curl);
		$error=curl_errno($curl);
		$error_msg=curl_error($curl);
		curl_close($curl);

		if($error){
			return $error_msg;
		}else{
			$response=preg_split("/\r\n\r\n|\n\n|\r\r/",$response,2);
			$headers=array();
			$headers_content=explode("\n",$response[0]);
			$headers['status']=$headers_content[0];

			array_shift($headers_content);

			foreach($headers_content as $content){
				$data=explode(':',$content);
				$headers[trim($data[0])]=trim($data[1]);
			}
			return array('headers'=>$headers,'body'=>$response[1]);
		}
	}


	public function add_hook($topic,$shop,$location_id,$app_version,$access_token,$fun){
		$base_path ='https://app.zanvos.com';
		$url = $base_path."/".$fun."?shop=" . $shop."&l_id=".$location_id;		
		$curl = curl_init();			
		curl_setopt_array($curl, array(			
		CURLOPT_URL => 'https://'.$shop.'/admin/api/'.$app_version.'/webhooks.json',			
		CURLOPT_RETURNTRANSFER => true,			
		CURLOPT_ENCODING => '',			
		CURLOPT_MAXREDIRS => 10,			
		CURLOPT_TIMEOUT => 0,			
		CURLOPT_FOLLOWLOCATION => true,			
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,			
		CURLOPT_CUSTOMREQUEST => 'POST',			
		CURLOPT_POSTFIELDS =>'{"webhook":{"topic":"'.$topic.'","address":"'.$url.'","format":"json","fields":["id","note"]}}',CURLOPT_HTTPHEADER => array(			
				'X-Shopify-Access-Token: '.$access_token,			
				'Content-Type: application/json'			
			),			
		));			
		$response = curl_exec($curl);	
		curl_close($curl);	
		
		$response = json_decode($response, true);
		if (isset($response['errors']) ){
			return $response;
		}

		return (is_array($response) and ( count($response) > 0)) ? array_shift($response) : $response;	
		
	}	
	
}	
