<script>
var intervals = []; //prepare the intervals holder
function countdown(nr,initime,endtxt){
    var selector = ".timer";//actual class name will be .timer_123 (if nr=123)
    var timer2 = initime; //"71:10:07"; //unlimited hours
    
    intervals['countdown_'+nr] = setInterval(function() {
        var timer = timer2.split(':');
        //by parsing integer, I avoid all extra string processing
        var hours = parseInt(timer[0], 10);
        var minutes = parseInt(timer[1], 10);
        var seconds = parseInt(timer[2], 10);
        
        --seconds; //decrement secs first
         
        minutes = (seconds < 0) ? --minutes : minutes;
        hours = (minutes < 0) ? --hours : hours;

            
        if (hours < 0 && minutes < 0 && seconds < 0) {
            clearInterval(intervals['countdown_'+nr]);
            $(selector+"_"+nr).html(endtxt);
        } else {
            //console.log(selector+"_"+nr, timer, timer2);
            
            //do 59 reset here to allow detection of negative values above
            seconds = (seconds < 0) ? 59 : seconds;
            minutes = (minutes < 0) ? 59 : minutes;         
            
            //set new timer value
            timer2 = hours + ':' + minutes + ':' + seconds;
            
            //start changes for display only
            seconds = (seconds < 10) ? '0' + seconds : seconds;
            minutes = (minutes < 10) ? '0' + minutes : minutes; 
            $(selector+"_"+nr).html(hours + ' hrs : ' + minutes + ' mins : ' + seconds + ' seconds');
            
        } 
        
    }, 1000);   
}
</script>
<script>countdown('2','{{ product.metafields.custom.countdown_time.value }}:00',"timer has ended");</script>
=====================================================================================================================
<script>
setTimeout(function(){
var dateString = new Date();
var tdf= dateString.setDate(dateString.getDate() + 15); 
var tdf1 = new Date(tdf);
var yar=new Date().getFullYear();
var ddate = tdf1.toString().split(' '+yar)[0];
var td=':'+ddate+'th';
var newStr = td.replace(" ", ",");
$(".timertimer_2").append(newStr);
},1100);
</script>